#include <RcppArmadillo.h>
#include <limits>
#include <omp.h>
#define min(x,y) (((x) < (y)) ? (x) : (y))


using namespace std;
using namespace Rcpp;
using namespace arma;



// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// calculate likelihood part
// Gaussian mixture likelihood
double logLik(mat X, mat CC, double omega, vec prob){
	
int nXrows = X.n_rows;    
int nCCrows = CC.n_rows;    
rowvec d;
vec dummy; 
vec res = zeros(nXrows);

for(int i = 0; i< nXrows; i++){
    for(int j = 0; j< nCCrows; j++){	
        d =  X.row(i) - CC.row(j);
        dummy =  (d*trans(d)); 
        res[i] = res[i] + prob[j]*(1/(2*(M_PI)*omega*omega))*exp(-dummy[0]/(2*omega*omega));
    }
}

double loglik = sum(log(res));
return(loglik);
}




// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// calculate likelihood part
// Spatiotemporal Gaussian mixture likelihood
double logLikST(mat X, mat CC, double omegas, double omegat, vec prob){
	
int nXrows = X.n_rows;    
int nCCrows = CC.n_rows;    
rowvec d;
vec res = zeros(nXrows);
double xdiff, ydiff, tdiff; 

for(int i = 0; i< nXrows; i++){
    for(int j = 0; j< nCCrows; j++){	
	    d =  X.row(i) - CC.row(j);
	    xdiff = d[0];
	    ydiff = d[1];
	    tdiff = d[2];
        res[i] = res[i] + prob[j]*(1/(2*(M_PI)*omegas*omegas))*(1/sqrt(2*(M_PI)*omegat*omegat))*exp(-( xdiff*xdiff/(2*omegas*omegas) + ydiff*ydiff/(2*omegas*omegas) + tdiff*tdiff/(2*omegat*omegat) ));
    }
}

double loglik = sum(log(res));
return(loglik);
}





// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// calculate likelihood part
// Spatiotemporal Gaussian mixture likelihood with landmark
double logLikSTLandmark(mat X, mat Z1, mat Z2, mat Z3, mat Z4, mat Z5, mat Z6, mat CC, double omegas, double omegat, vec omega, vec prob){
	
int nXrows = X.n_rows;    
int nCCrows = CC.n_rows;    
rowvec d;
vec res = zeros(nXrows);
double xdiff,ydiff,tdiff,xdiff1,ydiff1,xdiff2,ydiff2,xdiff3,ydiff3,xdiff4,ydiff4,xdiff5,ydiff5,xdiff6,ydiff6;  

for(int i = 0; i< nXrows; i++){
    for(int j = 0; j< nCCrows; j++){	
	    d =  X.row(i) - CC.row(j);
	    xdiff = d[0];
	    ydiff = d[1];
	    tdiff = d[2];

        // distance between center and landmark
        xdiff1 = Z1(i,0) - CC(j,0), ydiff1 = Z1(i,1) - CC(j,1);
        xdiff2 = Z2(i,0) - CC(j,0), ydiff2 = Z2(i,1) - CC(j,1);
        xdiff3 = Z3(i,0) - CC(j,0), ydiff3 = Z3(i,1) - CC(j,1);
        xdiff4 = Z4(i,0) - CC(j,0), ydiff4 = Z4(i,1) - CC(j,1);
        xdiff5 = Z5(i,0) - CC(j,0), ydiff5 = Z5(i,1) - CC(j,1);
        xdiff6 = Z6(i,0) - CC(j,0), ydiff6 = Z6(i,1) - CC(j,1);

			   
        res[i] = res[i] + prob[j]*(1/(2*(M_PI)*omegas*omegas))*(1/sqrt(2*(M_PI)*omegat*omegat))*(1/(2*(M_PI)*omega[0]*omega[0]))*(1/(2*(M_PI)*omega[1]*omega[1]))*(1/(2*(M_PI)*omega[2]*omega[2]))*
                                  (1/(2*(M_PI)*omega[3]*omega[3]))*(1/(2*(M_PI)*omega[4]*omega[4]))*(1/(2*(M_PI)*omega[5]*omega[5]))*
		        exp(-( xdiff*xdiff/(2*omegas*omegas) + ydiff*ydiff/(2*omegas*omegas) + tdiff*tdiff/(2*omegat*omegat)  + xdiff1*xdiff1/(2*omega[0]*omega[0]) + ydiff1*ydiff1/(2*omega[0]*omega[0]) +
		        xdiff2*xdiff2/(2*omega[1]*omega[1]) + ydiff2*ydiff2/(2*omega[1]*omega[1]) + xdiff3*xdiff3/(2*omega[2]*omega[2]) + ydiff3*ydiff3/(2*omega[2]*omega[2]) + xdiff4*xdiff4/(2*omega[3]*omega[3]) + ydiff4*ydiff4/(2*omega[3]*omega[3]) + 
				xdiff5*xdiff5/(2*omega[4]*omega[4]) + ydiff5*ydiff5/(2*omega[4]*omega[4]) + xdiff6*xdiff6/(2*omega[5]*omega[5]) + ydiff6*ydiff6/(2*omega[5]*omega[5]) ));
		
    }
}

double loglik = sum(log(res));
return(loglik);
}



















































// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// calculate likelihood part
// Spatiotemporal Gaussian mixture conditional likelihood with landmark
double logCondLikSTLandmark(mat Z1, mat Z2, mat Z3, mat Z4, mat Z5, mat Z6, mat CC, vec omega, vec prob){
	
int nZrows = Z1.n_rows;    
int nCCrows = CC.n_rows;    
rowvec d;
vec res = zeros(nZrows);
double xdiff1,ydiff1,xdiff2,ydiff2,xdiff3,ydiff3,xdiff4,ydiff4,xdiff5,ydiff5,xdiff6,ydiff6;  

for(int i = 0; i< nZrows; i++){
    for(int j = 0; j< nCCrows; j++){	

        // distance between center and landmark
        xdiff1 = Z1(i,0) - CC(j,0), ydiff1 = Z1(i,1) - CC(j,1);
        xdiff2 = Z2(i,0) - CC(j,0), ydiff2 = Z2(i,1) - CC(j,1);
        xdiff3 = Z3(i,0) - CC(j,0), ydiff3 = Z3(i,1) - CC(j,1);
        xdiff4 = Z4(i,0) - CC(j,0), ydiff4 = Z4(i,1) - CC(j,1);
        xdiff5 = Z5(i,0) - CC(j,0), ydiff5 = Z5(i,1) - CC(j,1);
        xdiff6 = Z6(i,0) - CC(j,0), ydiff6 = Z6(i,1) - CC(j,1);

			   
        res[i] = res[i] + prob[j]*(1/(2*(M_PI)*omega[0]*omega[0]))*(1/(2*(M_PI)*omega[1]*omega[1]))*(1/(2*(M_PI)*omega[2]*omega[2]))*
                                  (1/(2*(M_PI)*omega[3]*omega[3]))*(1/(2*(M_PI)*omega[4]*omega[4]))*(1/(2*(M_PI)*omega[5]*omega[5]))*
		        exp(-( xdiff1*xdiff1/(2*omega[0]*omega[0]) + ydiff1*ydiff1/(2*omega[0]*omega[0]) +
		        xdiff2*xdiff2/(2*omega[1]*omega[1]) + ydiff2*ydiff2/(2*omega[1]*omega[1]) + xdiff3*xdiff3/(2*omega[2]*omega[2]) + ydiff3*ydiff3/(2*omega[2]*omega[2]) + xdiff4*xdiff4/(2*omega[3]*omega[3]) + ydiff4*ydiff4/(2*omega[3]*omega[3]) + 
				xdiff5*xdiff5/(2*omega[4]*omega[4]) + ydiff5*ydiff5/(2*omega[4]*omega[4]) + xdiff6*xdiff6/(2*omega[5]*omega[5]) + ydiff6*ydiff6/(2*omega[5]*omega[5]) ));
		
    }
}

double loglik = sum(log(res));
return(loglik);
}





// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// calculate likelihood part
// Spatiotemporal Gaussian mixture likelihood
// truncated time kernel
double logLikST2(mat X, mat CC, double omegas, double omegat, vec prob){
	
int nXrows = X.n_rows;    
int nCCrows = CC.n_rows;    
rowvec d;
vec res = zeros(nXrows);
double xdiff, ydiff, tdiff; 
double non0 = 0; 
double loglik;
double negativeInf = -std::numeric_limits<float>::infinity();;

for(int i = 0; i< nXrows; i++){
    for(int j = 0; j< nCCrows; j++){	
	    d =  X.row(i) - CC.row(j);
	    xdiff = d[0];
	    ydiff = d[1];
	    tdiff = d[2];
	    
	    if(tdiff > 0 ){
        res[i] = res[i] + prob[j]*(1/(2*(M_PI)*omegas*omegas))*(1/sqrt(2*(M_PI)*omegat*omegat))*
	                            exp(-( xdiff*xdiff/(2*omegas*omegas) + ydiff*ydiff/(2*omegas*omegas) + tdiff*tdiff/(2*omegat*omegat) ))/(1-normcdf(0.001, CC(j,2), omegat));
		non0 = non0 + 1;	
		}else{ 
		res[i] = res[i] + 0;		
		}

    }
}



if(non0>0){ loglik = sum(log(res)); }else{ loglik = negativeInf; }

return(loglik);
}


	


// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
double hihi(double a, double b, double c){
	double ee = normcdf(a,b,c);
	return(ee);
}



// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// calculate likelihood part
// spatial liklihood
double logpXCbetaS(mat X, mat CC, vec prob, double alpha, double omega, double AreaW, vec integral){
	
int nXrows = X.n_rows;    
int nCCrows = CC.n_rows;    
rowvec d;
vec res;
vec dummy; 
vec lik = zeros(nCCrows);

for(int j = 0; j< nCCrows; j++){	
   res = zeros(nXrows);	
   
   for(int i = 0; i< nXrows; i++){    	
 	    d =  X.row(i) - CC.row(j);
		dummy =  (d*trans(d)); 
        res[i] = res[i] + exp(-dummy[0]/(2*omega*omega));
   }
   
   lik[j] = AreaW - alpha*integral[j] + nXrows*log(alpha/(2*(M_PI)*omega*omega)) + sum(log(res));   
}

double mx = lik.max();
double mixturelik = log(  sum(  prob%exp(lik-mx)  )  ) + mx;  

return(mixturelik);
}







// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// calculate likelihood part
// spatiotemporal likelihood 
double logpXCbeta(mat X, mat CC, vec prob, double alpha, double omegas, double omegat, double AreaW, double integral){
	
int nXrows = X.n_rows;    
int nCCrows = CC.n_rows;    
rowvec d;
vec res = zeros(nXrows);
double xdiff, ydiff, tdiff; 

for(int i = 0; i< nXrows; i++){
    for(int j = 0; j< nCCrows; j++){
	    d =  X.row(i) - CC.row(j);
	    xdiff = d[0];
	    ydiff = d[1];
	    tdiff = d[2];
        res[i] = res[i] + prob[j]*exp(-( xdiff*xdiff/(2*omegas*omegas) + ydiff*ydiff/(2*omegas*omegas) + tdiff*tdiff/(2*omegat*omegat) ));
    }
}
double lik = AreaW - alpha*integral + nXrows*log(  alpha*(1/(2*(M_PI)*omegas*omegas))*(1/sqrt(2*(M_PI)*omegat*omegat))  ) + sum(log(res));

return(lik);
}





















